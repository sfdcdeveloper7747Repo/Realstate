({

    fetchAllProperty : function(component, event, helper) {
    
    helper.fetchAllPropertyHelper(component, event, helper);
    
    }
    
    })